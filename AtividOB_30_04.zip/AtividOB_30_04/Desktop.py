from Produto import Produto

class Desktop(Produto):
    
    def __init__(self, modelo, cor, preco, categoria, potenciaDaFonte):
        super().__init__(modelo, cor, preco, categoria)
        self._potenciaDaFonte = potenciaDaFonte

    def getInformacoes(self, tipo_gabinete):
        return super().getInformacoes() , self.tipo_gabinete, self.sistema_refrigeracao
    

    