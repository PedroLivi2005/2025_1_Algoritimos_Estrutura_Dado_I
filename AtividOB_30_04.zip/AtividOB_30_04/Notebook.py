from Produto import Produto

class Notebook(Produto):
    
    def __init__(self, modelo, cor, preco, categoria,  tempoDeBateria):
        super().__init__(modelo, cor, preco, categoria)
        self.__tempoDeBateria = tempoDeBateria

    def getInformacoes(self):
        return super().getInformacoes() , self.peso, self.telaTamanho
    
    
    def get_modelo(self):
        return self.__tempoDeBateria
    
    
    def set_modelo(self, tempoDeBateria):
        if tempoDeBateria >= 0 :
            self.__tempoDeBateria = tempoDeBateria


